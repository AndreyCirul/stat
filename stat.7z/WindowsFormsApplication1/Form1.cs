﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int  flag =1;
        string text = "";
        

        private void probel_Click(object sender, EventArgs e)
        {
            flag = 1;
        }

        private void Zap_Click(object sender, EventArgs e)
        {
            flag = 2;
        }

        private void ZapIProbel_Click(object sender, EventArgs e)
        {
            flag = 3;
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!="" && textBox2.Text!="")
            {
            double[] array1 = new double[1];
            text = textBox1.Text;
            string zifr = "";
            int j = 0;
            if (flag == 1)
            {
                if (text[text.Length-1]!=' ')
                {
                    text += " ";
                }
                for (int i = 0; i < text.Length; i++)
                {
                    if (text[i] == ' ')
                    {
                        if (zifr != "")
                        {
                            double z = Convert.ToDouble(zifr);
                            array1[j] = z;
                            j++;
                            zifr = "";
                            if (i!=text.Length-1) Array.Resize<double>(ref array1, array1.Length + 1);
                        }

                    }
                    else
                    {
                        if (text[i] == '.') zifr += ",";
                        else zifr += text[i];
                    }
                }
            }
            if (flag == 2)
            {
                if (text[text.Length - 1] != ',')
                {
                    text += ",";
                }
                for (int i = 0; i < text.Length; i++)
                {
                    if (text[i] == ',')
                    {
                        if (zifr != "")
                        {
                            int z = Convert.ToInt32(zifr);
                            array1[j] = z;
                            j++;
                            zifr = "";
                            if (i != text.Length - 1) Array.Resize<double>(ref array1, array1.Length + 1);
                        }
                    }
                    else
                    {
                        if (text[i] == '.') zifr += ",";
                        else zifr += text[i];
                    }
                }
            }
            if (flag == 3)
            {
                if (text[text.Length - 1] != ' ')
                {
                    text += ", ";
                }
                for (int i = 0; i < text.Length; i++)
                {
                    if (text[i] == ' ')
                    {
                        if (zifr != "")
                        {
                            int z = Convert.ToInt32(zifr);
                            array1[j] = z;
                            j++;
                            zifr = "";
                            if (i != text.Length - 1) Array.Resize<double>(ref array1, array1.Length + 1);
                        }
                    }
                    else
                    {
                        if (text[i] != ',')
                        {
                            if (text[i] == '.') zifr += ",";
                            else zifr += text[i];
                        }
                    }
                }
            }
            double[][] array2 = new double[1][];
            bool f = true;
            double min = array1[0];
            int a = 0;
            while (f == true)
            {
                int ch=0;
                for (int i = array1.Length-1; i >=0; i--)
                {
                    if (array1[i] != 0) min = array1[i];
                }
                for (int i = 0; i < array1.Length; i++)
                {
                    if (array1[i] != 0)
                    {
                        if (min > array1[i]) min = array1[i];
                    }
                }
                for (int i = 0; i < array1.Length; i++)
                {
                    if (array1[i] == min)
                    {
                        ch++;
                        array1[i] = 0;
                    }
                }
                double[] gr = new double[2];
                gr[0] = min;
                gr[1] = ch;
                array2[a] = gr;
                
                a++;

                int g=0;
                for (int i = 0; i < array1.Length; i++)
                {
                    if (array1[i] != 0)
                    {
                        g++;
                    }
                }
                if (g == 0) f = false;
                else Array.Resize<double[]>(ref array2, array2.Length + 1);
            }
            Label[] lb = new Label[8];
            double H = 0;
            j = 0;
            double sum;
            double suma=0;
            double count;
            double counta = 0;
            double a1 = 0;
            double a2 = 0;
            double b1=0;
            double b2;
            double x0=0;
            double fm=0;
            double[] count1 = new double[1];
            double h = Convert.ToDouble(textBox2.Text);
            int n = 1;
            int m = 0;
            int mm = 0;
            double sm = 0;
            while (j < array2.Length) 
            {
                sum = 0;
                count = 0;
                if (j == 0) H = array2[j][0];
                double k=H+h;

                if (j != 0)
                {
                    H = k;
                    k += h;
                }
               
                               
                while ( j<array2.Length && array2[j][0] <k)
                {
                    
                    count += array2[j][1];
                    j++;
                }
                if (fm < count)
                {
                    fm = count;
                    x0 = H;
                    mm = m;
                    sm = counta;
                }
                counta += count;
                count1[m] = count;
                sum=(H+k)/2;
                if (j < array2.Length)
                {
                    m++;
                    Array.Resize<double>(ref count1, count1.Length + 1);
                    
                }
                
                lb[0] = new Label();
                lb[0].Text = Convert.ToString(n);
                lb[1] = new Label();
                lb[1].Text = Convert.ToString(H) + "-" + Convert.ToString(k);
                lb[2] = new Label();
                lb[2].Text = Convert.ToString(sum);
                suma += sum;
                lb[3] = new Label();
                lb[3].Text = Convert.ToString(count);
                
                lb[4] = new Label();
                lb[4].Text = Convert.ToString(sum / h);
                lb[5] = new Label();
                lb[5].Text = Convert.ToString(Math.Pow(sum, 2) / h);
                lb[6] = new Label();
                lb[6].Text = Convert.ToString((sum / h) * count);
                a1+=(sum / h) * count;
                lb[7] = new Label();
                lb[7].Text = Convert.ToString(Math.Pow(sum / h, 2) * count);
                a2 += Math.Pow(sum / h, 2) * count;
                n++;
                for (int i = 0; i < 8; i++)
                {
                    lb[i].Parent = tableLayoutPanel1;
                }
                b1 = k;
            }
            b2 = array2[1][0];
            suma /= n-1;
            lb[0] = new Label();
            lb[0].Text = "E";
            lb[1] = new Label();
            lb[1].Text = "h="+Convert.ToString(h);
            lb[2] = new Label();
            lb[2].Text = Convert.ToString(suma);
            lb[3] = new Label();
            lb[3].Text = Convert.ToString(counta);
            lb[4] = new Label();
            lb[4].Text = "";
            lb[5] = new Label();
            lb[5].Text = "";
            lb[6] = new Label();
            lb[6].Text = Convert.ToString(a1);
            lb[7] = new Label();
            lb[7].Text = Convert.ToString(a2);
            for (int i = 0; i < 8; i++)
            {
                lb[i].Parent = tableLayoutPanel1;
            }
                double g1=0;
                for (int i = 0; i < array1.Length; i++) g1 += array1[i];
                g1=h*(g1/counta);
                double D = Math.Pow(h*suma, 2) - Math.Pow(g1, 2);
                label14.Text=Convert.ToString(suma);
                label15.Text = Convert.ToString(D);
                label17.Text =Convert.ToString( Math.Sqrt(D));
                double S = D * (counta / (counta - 1));
                label19.Text = Convert.ToString(S);
                label21.Text = Convert.ToString(Math.Pow(S,2));
                label26.Text = Convert.ToString(b1-b2);
                label27.Text = Convert.ToString(array2[array2.Length - 1][0]);

                if (mm != count1.Length - 1)
                {
                    double fm1 = count1[mm - 1];
                    double fm2 = count1[mm + 1];
                    label28.Text = Convert.ToString(x0 + h * ((fm - fm1) / (fm - fm1) + (fm + fm2)));
                }
                else
                {
                    label28.Text = "0";
                }
                label29.Text = Convert.ToString(x0+h*((suma-sm)/fm));
        }
    }
    }
}
